
extern zend_class_entry *phalcon_filter_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Filter_Exception);

