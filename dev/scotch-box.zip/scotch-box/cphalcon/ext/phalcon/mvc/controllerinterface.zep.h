
extern zend_class_entry *phalcon_mvc_controllerinterface_ce;

ZEPHIR_INIT_CLASS(Phalcon_Mvc_ControllerInterface);

