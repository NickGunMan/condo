
Documentation
=============
Visit http://docs.phalconphp.com for a full documentation